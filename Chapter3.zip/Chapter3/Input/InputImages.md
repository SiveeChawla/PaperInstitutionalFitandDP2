The folder consists of two sets of input images used in the chapter . 

Case 1_Low Heterogeneity Landscapes

Case 2_High Heterogeneity Landscapes
