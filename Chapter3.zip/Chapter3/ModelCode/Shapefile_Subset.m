%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Created by: Sivee Chawla
% Created on: 8 June 2018
% Purpose :Subset Shapefile
% comments :  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function[Ss,Aa] = Shapefile_Subset()

%enter the the siz of bounding box
% xmin = input('Enter xmin for bbox');
% xmax = input('Enter xmax for bbox');
% ymin = input('Enter ymin for bbox');
% ymax = input('Enter ymax for bbox');
% bbox = [xmin,ymin;xmax,ymax];
% bbox = [1,1;9,9];

%Ss = shaperead('C:\Users\jc442626\Documents\PhD\PhD_Tasks_imp\RQ1\VectorFiles_ShapeFiles\SimInput_n30.shp', 'BoundingBox',bbox);

% xmin 
% xmax 
% ymin 
% ymax
% 
% mapshow(Ss);
end

